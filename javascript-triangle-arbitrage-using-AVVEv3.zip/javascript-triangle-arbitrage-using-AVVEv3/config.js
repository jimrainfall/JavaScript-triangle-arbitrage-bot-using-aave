var myaddress = "your wallet address"
var myprivatekey = "your privatekey to address"
var myseed = "your wallet seed" //only give this if your privatekey is stored in a wallet with accessibility example (hardwarewallets)
var networks = "1" //1 = ETH , 2 = BNB , 3 = Polygon Note: you can set it to "4" to look at all 3 networks but make sure you have eth ,bnb and matic in the same address you put in "myaddress" or wallet seed
